<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AccountModel extends CI_Model{

  public function __construct()
  {
    parent::__construct();
    //Codeigniter : Write Less Do More
  }

  function Login($username,$password){
    //count if the user exists
      $query = $this->db->select('*')
                ->where('username', $username)
                ->where('password', pw_hash($password))
                ->get('users')->num_rows();
      return $query;
  }

function setCredentials($username,$password){
  //setting credentials
    $this->db->select('*');
    $this->db->from('users');
    $this->db->where('username', $username);
    $this->db->where('password', pw_hash($password));

  $result = $this->db->get();
  return $result->result();
}


  function Register($data){
    if(!$this->db->insert('users',$data)){
      return $this->db->error();
    }
  }


  function checkusername($username){
    $query = $this->db->select('*')
              ->where('username', $username)
              ->where('password', pw_hash($password))
              ->get('users')->num_rows();

    $result = ($query ==0 ? 0 : 1);

    return $query;
  }

}
