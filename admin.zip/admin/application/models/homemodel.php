<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class HomeModel extends CI_Model{

  public function __construct()
  {
    parent::__construct();
    //Codeigniter : Write Less Do More
  }

  function mainmenu($page){
    //get the ID of module group
    $groupid = 0;
    $query = "SELECT * FROM module_group WHERE pagecode ='" . $page . "'";
    $result = $this->db->query($query)->result();
    foreach ($result as $key) {
      $groupid = $key->id;
    }

    //Select the modules
    $query = "SELECT * FROM modules WHERE module_group_id = $groupid";
    return $this->db->query($query)->result();
  }

  function groupmodule($page){
    $query = "SELECT * FROM module_group WHERE pagecode ='" . $page . "'";
    $result = $this->db->query($query)->result();
    return $result;
  }

}
