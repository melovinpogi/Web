<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Account extends CI_Controller{

  public function __construct()
  {
    parent::__construct();
    script_css();
    script_js();
  }

  function index(){
    if(user_id() == '' || user_id() == 0 ){
          $data["err"] = "";
	        $this->load->view('account/login_view',$data);
	     }else{
	     	$this->load->view('index');
	     }
  }


  function login(){
    $username = $this->input->post('username');
		$password = $this->input->post('password');

    $exists = $this->AccountModel->Login($username,$password);

    if($exists == 0){
        $data["err"] = "<div class='alert alert-danger'>Invalid Username/Password! <i class='fa fa-close'></i></div>";
        $this->load->view('account/login_view',$data);
    }else{
      //store credentials
      $result = $this->AccountModel->setCredentials($username,$password);
      $sess_data = array();
         foreach($result as $row){
           $sess_array = array(
             'userid' => $row->id,
             'username' => $row->firstname,
             'useremail' => $row->email
           );
         }
         $this->session->set_userdata('logged_in', $sess_array);
         redirect("home","refresh");
    }


  }


  function logout(){
    $array_items = array('userid' => 0,
              'username' => '',
              'useremail' => ''
						);
      	$this->session->unset_userdata($array_items);
      	$this->session->sess_destroy();
      	redirect('', 'refresh');
  }

  function signup(){
    	$this->load->view('account/register_view');
  }

  function register(){
    $newuser = array('firstname' 		 => $this->input->post('firstname') ,
    								'lastname' 		   => $this->input->post('lastname'),
    								'email'          => $this->input->post('email'),
    								'mobile' 		     => $this->input->post('mobile'),
    								'username' 		   => $this->input->post('username'),
    								'password' 		   => pw_hash($this->input->post('password')),
                    'avatar'         => 'assets/img/icon.png',
                    'online'        => 0,
                    'created_at'    => date("Y-m-d H:i:s"),
                    'updated_at'    => date("Y-m-d H:i:s"),
                    'status'        => 1);

    if ($this->AccountModel->Register($newuser)) {
      redirect('login','refresh');
    }


  }


function checkusername(){
  $checkusername = $this->AccountModel->checkusername( $this->input->post('username') );
  return $checkusername == 0 ? 0 : 1;
}

}
