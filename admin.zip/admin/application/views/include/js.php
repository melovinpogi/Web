<script>
var resizefunc = [];
</script>
<script src="<?php echo base_url(); ?>assets/libs/jquery/jquery-1.11.1.min.js"></script>
<script src="<?php echo base_url(); ?>assets/libs/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/libs/jqueryui/jquery-ui-1.10.4.custom.min.js"></script>
<script src="<?php echo base_url(); ?>assets/libs/jquery-ui-touch/jquery.ui.touch-punch.min.js"></script>
<script src="<?php echo base_url(); ?>assets/libs/jquery-animate-numbers/jquery.animateNumbers.js"></script>
<script src="<?php echo base_url(); ?>assets/libs/fastclick/fastclick.js"></script>
<script src="<?php echo base_url(); ?>assets/libs/jquery-slimscroll/jquery.slimscroll.js"></script>
<script src="<?php echo base_url(); ?>assets/libs/sortable/sortable.min.js"></script>
<script src="<?php echo base_url(); ?>assets/libs/bootstrap-fileinput/bootstrap.file-input.js"></script>
<script src="<?php echo base_url(); ?>assets/libs/bootstrap-select/bootstrap-select.min.js"></script>
<script src="<?php echo base_url(); ?>assets/libs/bootstrap-select2/select2.min.js"></script>
<script src="<?php echo base_url(); ?>assets/libs/magnific-popup/jquery.magnific-popup.min.js"></script>
<script src="<?php echo base_url(); ?>assets/libs/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
<script src="<?php echo base_url(); ?>assets/libs/jquery-icheck/icheck.min.js"></script>
<script src="<?php echo base_url(); ?>assets/libs/prettify/prettify.js"></script>

<script src="<?php echo base_url(); ?>assets/js/init.js"></script>
<!-- Page Specific JS Libraries -->
<script src="<?php echo base_url(); ?>assets/libs/d3/d3.v3.js"></script>
<script src="<?php echo base_url(); ?>assets/libs/rickshaw/rickshaw.min.js"></script>
<script src="<?php echo base_url(); ?>assets/libs/raphael/raphael-min.js"></script>
<script src="<?php echo base_url(); ?>assets/libs/morrischart/morris.min.js"></script>
<script src="<?php echo base_url(); ?>assets/libs/jquery-knob/jquery.knob.js"></script>
<script src="<?php echo base_url(); ?>assets/libs/bootstrap-xeditable/js/bootstrap-editable.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/pages/index.js"></script>
