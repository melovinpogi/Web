<body>
	<div class="container">
    <script type="text/javascript">
    var count = 3;

    function countDown(){
        var timer = document.getElementById("timer");
        if(count > 0){
            count--;
            timer.innerHTML = "This page will redirect in "+count+" seconds.";
            setTimeout('countDown()',1000);
        }else{
            window.location.href = <?php print_r($url); ?>;
        }
    }
    </script>

		<?php print_r($string); ?>
    <span id="timer">
      <script type="text/javascript">countDown();</script>
    </span>
	</div>
</body>
</html>
