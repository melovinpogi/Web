<body class="fixed-left">
<!-- Begin page -->
<div id="wrapper">

<!-- Top Bar Start -->
<?php $this->load->view('menu/topbar'); ?>
<!-- Top Bar End -->
		<!-- Left Sidebar Start -->
		<?php $this->load->view('menu/leftbar'); ?>
		<!-- Left Sidebar End -->
<!-- Start right content -->
		<div class="content-page">
	<!-- ============================================================== -->
	<!-- Start Content here -->
	<!-- ============================================================== -->
				<div class="content">
					<!-- Start info box -->
					<div class="row top-summary">
						<div class="col-lg-6 col-md-6">
							<div class="widget green-1 animated fadeInDown">
								<div class="widget-content padding">
									<div class="widget-icon">
										<i class="icon-globe-inv"></i>
									</div>
									<div class="text-box">
										<p class="maindata">TOTAL <b>VISITORS</b></p>
										<h2><span class="animate-number" data-value="25153" data-duration="3000">0</span></h2>
										<div class="clearfix"></div>
									</div>
								</div>
								<div class="widget-footer">
									<div class="row">
										<div class="col-sm-12">
											<i class="fa fa-caret-up rel-change"></i> <b>39%</b> increase in traffic
										</div>
									</div>
									<div class="clearfix"></div>
								</div>
							</div>
						</div>

						<div class="col-lg-6 col-md-6">
							<div class="widget darkblue-2 animated fadeInDown">
								<div class="widget-content padding">
									<div class="widget-icon">
										<i class="icon-bag"></i>
									</div>
									<div class="text-box">
										<p class="maindata">TOTAL <b>SALES</b></p>
										<h2><span class="animate-number" data-value="6399" data-duration="3000">0</span></h2>

										<div class="clearfix"></div>
									</div>
								</div>
								<div class="widget-footer">
									<div class="row">
										<div class="col-sm-12">
											<i class="fa fa-caret-down rel-change"></i> <b>11%</b> decrease in sales
										</div>
									</div>
									<div class="clearfix"></div>
								</div>
							</div>
						</div>

						<div class="col-lg-6 col-md-6">
							<div class="widget orange-4 animated fadeInDown">
								<div class="widget-content padding">
									<div class="widget-icon">
										<i class="fa fa-dollar"></i>
									</div>
									<div class="text-box">
										<p class="maindata">OVERALL <b>INCOME</b></p>
										<h2>$<span class="animate-number" data-value="70389" data-duration="3000">0</span></h2>
										<div class="clearfix"></div>
									</div>
								</div>
								<div class="widget-footer">
									<div class="row">
										<div class="col-sm-12">
											<i class="fa fa-caret-down rel-change"></i> <b>7%</b> decrease in income
										</div>
									</div>
									<div class="clearfix"></div>
								</div>
							</div>
						</div>

						<div class="col-lg-6 col-md-6">
							<div class="widget lightblue-1 animated fadeInDown">
								<div class="widget-content padding">
									<div class="widget-icon">
										<i class="fa fa-users"></i>
									</div>
									<div class="text-box">
										<p class="maindata">TOTAL <b>USERS</b></p>
										<h2><span class="animate-number" data-value="18648" data-duration="3000">0</span></h2>
										<div class="clearfix"></div>
									</div>
								</div>
								<div class="widget-footer">
									<div class="row">
										<div class="col-sm-12">
											<i class="fa fa-caret-up rel-change"></i> <b>6%</b> increase in users
										</div>
									</div>
									<div class="clearfix"></div>
								</div>
							</div>
						</div>

					</div>
					<!-- End of info box -->
				<!-- Footer Start -->
							<?php $this->load->view('menu/footer'); ?>
			<!-- Footer End -->
				</div>
	<!-- ============================================================== -->
	<!-- End content here -->
	<!-- ============================================================== -->
		</div>
<!-- End right content -->

</div>
<!-- End of page -->
</body>
</html>
