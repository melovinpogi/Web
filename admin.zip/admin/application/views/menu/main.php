<body class="fixed-left">
<!-- Begin page -->
<div id="wrapper">

<!-- Top Bar Start -->
<?php $this->load->view('menu/topbar'); ?>
<!-- Top Bar End -->
		<!-- Left Sidebar Start -->
		<?php $this->load->view('menu/leftbar'); ?>
		<!-- Left Sidebar End -->
<!-- Start right content -->
		<div class="content-page">
	<!-- ============================================================== -->
	<!-- Start Content here -->
	<!-- ============================================================== -->
				<div class="content">
					<!-- Start info box -->
					<?php foreach ($group as $g) { ?>
							<h1> <strong> <?php echo $g->module_group_name; ?></strong></h1>
							<div class="row">
								<?php foreach ($result as $value) { ?>
									<?php
										$icon = "";
										$color = "";
										$title = "";
											switch ($value->module_subgroup_id) {
												case 1:
														$icon = "fa fa-folder-open-o"; //masterfiles
														$color = "darkblue-2";
														$title = "Masterfile";
													break;
												case 2:
														$icon = "fa fa-file-text-o"; //transaction
														$color = "green-1";
														$title = "Transaction";
													break;
												case 3:
														$icon = "fa fa-book"; //report
														$color = "orange-4";
														$title = "Report";
													break;
												default:
													# code...
													break;
											}
										?>
										<a href="<?php echo base_url() . $value->link; ?>">
											<div class="col-lg-3 col-md-3">
												<div class="widget <?php echo $color; ?> animated fadeInDown">
													<div class="widget-content padding">
														<div class="widget-icon">
															<i class="<?php echo $icon; ?>"></i>
														</div>
														<div class="text-box">
															<p class="maindata"><?php echo $value->module_name . " <br>" . $title; ?></b></p>
															<div class="clearfix"></div>
														</div>
													</div>
												</div>
											</div>
										</a>
								<?php } ?>
							</div>
					<?php } ?>
					<!-- End of info box -->
				<!-- Footer Start -->
							<?php $this->load->view('menu/footer'); ?>
			<!-- Footer End -->
				</div>
	<!-- ============================================================== -->
	<!-- End content here -->
	<!-- ============================================================== -->
		</div>
<!-- End right content -->

</div>
<!-- End of page -->
</body>
</html>
<style media="screen">
	.widget .text-box .maindata {
		font-size: 30px;
	}
</style>
