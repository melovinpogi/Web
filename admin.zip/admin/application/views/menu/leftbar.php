<div class="left side-menu">
    <div class="sidebar-inner slimscrollleft">
        <div class="clearfix"></div>
        <!--- Profile -->
        <div class="profile-info">
            <div class="col-xs-4">
              <a href="profile.html" class="rounded-image profile-image"><img src="<?php echo base_url(); ?>assets/img/icon.png"></a>
            </div>
            <div class="col-xs-8">
                <div class="profile-text">Welcome <b><?= logged(); ?></b></div>
            </div>
        </div>
        <!--- Divider -->
        <div class="clearfix"></div>
        <hr class="divider" />
        <div class="clearfix"></div>
        <!--- Divider -->
        <div id="sidebar-menu">
            <ul>
              <li>
                <a href='menu/timezone' class='active'>
                  <i class="fa fa-clock-o"></i><span>Time Zone</span>
                </a>
              </li>
            </ul>
        </div>
    <div class="clearfix"></div>
</div>

</div>
