<body class="fixed-left login-page">
	<div class="container">
		<div class="full-content-center">
			<p class="text-center"><a href="#"><img src="assets/img/login-logo.png" alt="Logo"></a></p>
			<div class="login-wrap animated flipInX">
				<div class="login-block">
					<img src="images/users/default-user.png" class="img-circle not-logged-avatar">
					<form role="form" action="account/register" method="post">
						<div class="form-group login-input">
							<i class="fa fa-user overlay"></i>
							<input type="text" class="form-control text-input" placeholder="Firstname" name="firstname" required>
						</div>
						<div class="form-group login-input">
							<i class="fa fa-user overlay"></i>
							<input type="text" class="form-control text-input" placeholder="Lastname" name="lastname" required>
						</div>
						<div class="form-group login-input">
							<i class="fa fa-envelope overlay"></i>
							<input type="email" class="form-control text-input" placeholder="Email" name="email" required>
						</div>
						<div class="form-group login-input">
							<i class="fa fa-phone overlay"></i>
							<input type="number" class="form-control text-input" placeholder="Mobile" name="mobile" required>
						</div>
						<div class="form-group login-input">
							<i class="fa fa-user overlay"></i>
							<input type="text" class="form-control text-input" placeholder="Username" name="username" required>
						</div>
						<div class="form-group login-input">
							<i class="fa fa-key overlay"></i>
							<input type="password" class="form-control text-input" placeholder="********" name="password" required>
						</div>
						<div class="row">
							<div class="col-sm-12">
								<input type="submit" value="Register" class="btn btn-success btn-block">
							</div>
							<div class="col-sm-12">
								<input type="login" value="Login" class="btn btn-primary btn-block">
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</body>
</html>

<script type="text/javascript">
$(document).ready(function () {
		$("form").submit(function (e) {
				e.preventDefault(); //prevent default form submit

				if ($(this).valid()) {

						var uname= $('input[username]').val();

						$.ajax({
								url: '/Home/CheckUserExist/',        //ControllerName/ActionName/
								data: {
										username: uname
								},
								success: function (data) {
										if (data == 0) {
											$("form").unbind('submit').submit();
										}else{
											alert(data);
										}
								},
								cache: false
						});
				}
		});
});


</script>
