<body class="fixed-left login-page">
	<div class="container">
		<div class="full-content-center">
			<p class="text-center"><a href="#"><img src="<?php  echo base_url(); ?>assets/img/signin.png" alt="Logo"></a></p>
			<div class="login-wrap animated flipInX">
				<div class="login-block">
					<?php print_r($err); ?>
					<?php echo form_open('login','role="form"'); ?>
						<div class="form-group login-input">
						<i class="fa fa-user overlay"></i>
						<input type="text" class="form-control text-input" placeholder="Username" name="username">
						</div>
						<div class="form-group login-input">
						<i class="fa fa-key overlay"></i>
						<input type="password" class="form-control text-input" placeholder="********" name="password">
						</div>

						<div class="row">
							<div class="col-sm-12">
							<input type="submit" value="Login" class="btn btn-success btn-block">
							</div>
						</div>
					 <?php echo form_close(); ?>
				</div>
			</div>

		</div>
	</div>
</body>
</html>

<style media="screen">
	.login-page {
		background: #ffffff;
	}
</style>
