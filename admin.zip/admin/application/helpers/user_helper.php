<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

function logged(){
	$CI =& get_instance();
	$CI->load->library('session');
	$session_data  = $CI->session->userdata('logged_in');
	return $session_data['username'];
}
function user_id(){
	$CI =& get_instance();
	$CI->load->library('session');
	$session_data  = $CI->session->userdata('logged_in');
	return $session_data['userid'];
}
function user_type(){
	$CI =& get_instance();
	$CI->load->library('session');
	$session_data  = $CI->session->userdata('logged_in');
	return $session_data['usertype'];
}
function user_email(){
	$CI =& get_instance();
	$CI->load->library('session');
	$session_data  = $CI->session->userdata('logged_in');
	return $session_data['useremail'];
}

function pw_hash($pass){
	return "M3L0^_^".substr(hash('sha512', $pass),0,-4);
}
