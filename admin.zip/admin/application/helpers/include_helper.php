<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
function script_css(){
	$CI =& get_instance();
	$content = $CI->load->view('include/css');

	return $content;
}
function script_js(){
	$CI =& get_instance();
	$content = $CI->load->view('include/js');

	return $content;
}
function leftmenu(){
	$CI =& get_instance();
	$content = $CI->load->view('menu/left-menu');

	return $content;
}
/* End of file User_helper.php */
/* Location: ./application/helpers/Menu_helper.php */
